using Microsoft.AspNetCore.Mvc;
using WatchtowerInventory.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WatchtowerInventory.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index(string searchTerm, string genre, string priceRange, string inStock, string publisher, string sortBy)
        {
            // Get all comics (including ones added via Admin)
            var comics = ComicRepository.GetAll();

            // ✅ Add 12 static comics only if list is empty
            if (comics == null || !comics.Any())
            {
                comics = new List<Comic>
                {
                    new Comic { Title = "The Watcher", Author = "J.D. Payne", Genre = "Sci-Fi", Price = 9.99M, Stock = 5, Publisher = "SkyBound", ImageUrl = "/images/book1.jpg" },
                    new Comic { Title = "Ghost City", Author = "Lana West", Genre = "Mystery", Price = 7.99M, Stock = 6, Publisher = "GhostPrint", ImageUrl = "/images/book2.jpg" },
                    new Comic { Title = "Quantum Zone", Author = "Rick Meyers", Genre = "Sci-Fi", Price = 12.50M, Stock = 4, Publisher = "NovaCore", ImageUrl = "/images/book3.jpg" },
                    new Comic { Title = "Steel Heart", Author = "M. Brandon", Genre = "Action", Price = 10.00M, Stock = 9, Publisher = "TitanForge", ImageUrl = "/images/book4.jpg" },
                    new Comic { Title = "Shadow Realm", Author = "Tasha Ling", Genre = "Fantasy", Price = 11.25M, Stock = 2, Publisher = "DarkGate", ImageUrl = "/images/book5.jpg" },
                    new Comic { Title = "Cyber Skies", Author = "Neo Vance", Genre = "Cyberpunk", Price = 8.75M, Stock = 5, Publisher = "GridLock", ImageUrl = "/images/book6.jpg" },
                    new Comic { Title = "Dragon Fire", Author = "Eli Thorn", Genre = "Fantasy", Price = 9.99M, Stock = 3, Publisher = "MythicInk", ImageUrl = "/images/book7.jpg" },
                    new Comic { Title = "Arcade Outlaws", Author = "Nick Fury", Genre = "Retro", Price = 7.49M, Stock = 7, Publisher = "PixelPunch", ImageUrl = "/images/book8.jpg" },
                    new Comic { Title = "Mega Mice", Author = "T. Cheese", Genre = "Kids", Price = 5.99M, Stock = 6, Publisher = "MouseHouse", ImageUrl = "/images/book9.jpg" },
                    new Comic { Title = "Alien Dreams", Author = "Zara Volt", Genre = "Sci-Fi", Price = 13.45M, Stock = 8, Publisher = "VoidComics", ImageUrl = "/images/book10.jpg" },
                    new Comic { Title = "City of Ice", Author = "J. Frost", Genre = "Thriller", Price = 6.60M, Stock = 4, Publisher = "FreezeLine", ImageUrl = "/images/book11.jpg" },
                    new Comic { Title = "The Forgotten Path", Author = "Yuki Mura", Genre = "Adventure", Price = 10.00M, Stock = 5, Publisher = "TrekTales", ImageUrl = "/images/book12.png" }
                };
            }

            // Search
            if (!string.IsNullOrEmpty(searchTerm))
            {
                searchTerm = searchTerm.ToLower();
                comics = comics.Where(c =>
                    (c.Title?.ToLower().Contains(searchTerm) ?? false) ||
                    (c.Author?.ToLower().Contains(searchTerm) ?? false) ||
                    (c.Genre?.ToLower().Contains(searchTerm) ?? false)
                ).ToList();
            }

            // Genre
            if (!string.IsNullOrEmpty(genre))
            {
                comics = comics.Where(c => c.Genre == genre).ToList();
            }

            // Price Range
            if (!string.IsNullOrEmpty(priceRange))
            {
                switch (priceRange)
                {
                    case "under10":
                        comics = comics.Where(c => c.Price < 10).ToList();
                        break;
                    case "10to20":
                        comics = comics.Where(c => c.Price >= 10 && c.Price <= 20).ToList();
                        break;
                    case "above20":
                        comics = comics.Where(c => c.Price > 20).ToList();
                        break;
                }
            }

            // Stock
            if (inStock == "true")
            {
                comics = comics.Where(c => c.Stock > 0).ToList();
            }

            // Publisher
            if (!string.IsNullOrEmpty(publisher))
            {
                comics = comics.Where(c => c.Publisher == publisher).ToList();
            }

            // Sort
            switch (sortBy)
            {
                case "priceAsc":
                    comics = comics.OrderBy(c => c.Price).ToList();
                    break;
                case "priceDesc":
                    comics = comics.OrderByDescending(c => c.Price).ToList();
                    break;
            }

            return View(comics);
        }
    }
}
