package com.mycompany.bookings;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Bookings extends JFrame {

    // Store users (for login/register)
    private static final Map<String, String> users = new HashMap<>(); // Holds registered users and their passwords
    private final ArrayList<Booking> bookings = new ArrayList<>(); // Holds booking details
    private final Map<String, boolean[]> seatAvailability = new HashMap<>(); // Tracks seat availability for each movie

    // GUI components
    private JTextField usernameField = null; // Input field for username
    private JPasswordField passwordField = null; // Input field for password
    private JTextArea bookingDetailsArea; // Area to display booking details

    // Constructor to set up the main window
    public Bookings() {
        setTitle("Movie Booking System"); // Title of the window
        setSize(800, 600);  // Adjusted size for better fullscreen experience
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exit application on close
        setLayout(new BorderLayout()); // Use border layout for the main frame
        initializeSeats(); // Initialize seat availability for movies

        // Styling main window
        getContentPane().setBackground(new Color(50, 50, 50));  // Dark background color
        addLoginPanel(); // Add the login panel to the frame
        setVisible(true); // Make the window visible
    }

    // Method to initialize seats for movies
    private void initializeSeats() {
        String[] movies = {"Inception", "The Dark Knight", "Joker"}; // Movie titles
        for (String movie : movies) {
            seatAvailability.put(movie, new boolean[10]);  // 10 seats per movie initialized as available
        }
    }

    // Add login panel to the main window
    private void addLoginPanel() {
        // Create a panel for login components
        JPanel loginPanel = new JPanel(new GridLayout(3, 2, 10, 10)); // Grid layout for labels and fields
        loginPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50)); // Padding for the panel
        loginPanel.setBackground(new Color(80, 80, 80));  // Panel background color

        // Create labels and fields for username and password
        JLabel userLabel = new JLabel("Username:");
        userLabel.setForeground(Color.WHITE);  // White text for labels
        usernameField = new JTextField(); // Username input field
        JLabel passLabel = new JLabel("Password:");
        passLabel.setForeground(Color.WHITE);
        passwordField = new JPasswordField(); // Password input field

        // Create buttons for login and registration
        JButton loginButton = new JButton("Login");
        styleButton(loginButton); // Style the login button

        JButton registerButton = new JButton("Register");
        styleButton(registerButton); // Style the register button

        // Add action listeners for the buttons
        loginButton.addActionListener(new LoginListener());
        registerButton.addActionListener(new RegisterListener());

        // Add components to the login panel
        loginPanel.add(userLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passLabel);
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);
        loginPanel.add(registerButton);

        // Placeholder for a banner or image at the top
        JLabel banner = new JLabel("Your Banner Here", SwingConstants.CENTER);
        banner.setPreferredSize(new Dimension(400, 100)); // Banner size
        banner.setForeground(Color.WHITE);  // Text color
        banner.setBackground(new Color(100, 100, 100));  // Placeholder background color
        banner.setOpaque(true); // Make the background visible

        // Add the banner and login panel to the main window
        add(banner, BorderLayout.NORTH);  // Banner at the top
        add(loginPanel, BorderLayout.CENTER);
        revalidate(); // Refresh the layout
        repaint(); // Repaint the window
    }

    // Method to style buttons
    private void styleButton(JButton button) {
        button.setBackground(new Color(0, 153, 76));  // Green button color
        button.setForeground(Color.WHITE);  // White text
        button.setFocusPainted(false); // Remove focus painting
        button.setFont(new Font("Arial", Font.BOLD, 14)); // Set button font
    }

    // Show booking form after successful login
    private void showBookingForm(String username) {
        getContentPane().removeAll();  // Clear the current content

        // Create a panel for booking components
        JPanel bookingPanel = new JPanel(new GridLayout(6, 2, 10, 10));  // Layout for labels and fields
        bookingPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50)); // Padding
        bookingPanel.setBackground(new Color(80, 80, 80)); // Panel background color

        // Create labels and components for movie selection and ticket number
        JLabel movieLabel = new JLabel("Movie Name:");
        movieLabel.setForeground(Color.WHITE); // Set label color
        String[] movies = {"Inception", "The Dark Knight", "Joker"}; // Available movies
        JComboBox<String> movieDropdown = new JComboBox<>(movies); // Dropdown for movie selection

        JLabel ticketsLabel = new JLabel("Number of Tickets:");
        ticketsLabel.setForeground(Color.WHITE); // Set label color
        JTextField ticketsField = new JTextField(); // Field for number of tickets

        // Create buttons for booking and logout
        JButton bookButton = new JButton("Book");
        styleButton(bookButton); // Style the booking button

        JButton logoutButton = new JButton("Logout");
        styleButton(logoutButton); // Style the logout button

        // Action listener for booking button
        bookButton.addActionListener(e -> {
            String selectedMovie = (String) movieDropdown.getSelectedItem(); // Get selected movie
            try {
                int numTickets = Integer.parseInt(ticketsField.getText()); // Get number of tickets
                if (numTickets <= 0) throw new IllegalArgumentException("Tickets must be a positive number."); // Validation
                selectSeats(selectedMovie, numTickets, username); // Proceed to select seats
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number of tickets."); // Error handling
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage()); // Error handling
            }
        });

        // Action listener for logout button
        logoutButton.addActionListener(e -> {
            getContentPane().removeAll(); // Clear the content
            addLoginPanel(); // Show login panel again
            revalidate(); // Refresh the layout
            repaint(); // Repaint the window
        });

        // Add components to the booking panel
        bookingPanel.add(movieLabel);
        bookingPanel.add(movieDropdown);
        bookingPanel.add(ticketsLabel);
        bookingPanel.add(ticketsField);
        bookingPanel.add(bookButton);
        bookingPanel.add(logoutButton);

        // Placeholder for movie poster
        JLabel moviePoster = new JLabel();
        moviePoster.setPreferredSize(new Dimension(400, 700));  // Poster size
        ImageIcon posterIcon = new ImageIcon(getClass().getResource("/Photos/Joker_Poster.jpg")); 
        // Ensure this path is correct
        moviePoster.setIcon(posterIcon); // Set the movie poster icon
        moviePoster.setHorizontalAlignment(SwingConstants.CENTER); // Center align the poster

        // Add movie poster and booking panel to the main window
        add(moviePoster, BorderLayout.WEST);  // Add movie poster on the left
        add(bookingPanel, BorderLayout.CENTER); // Add booking panel to the center
        revalidate(); // Refresh the layout
        repaint(); // Repaint the window
    }

// Method to select seats for the booking
private void selectSeats(String movie, int numTickets, String username) {
    boolean[] seats = seatAvailability.get(movie); // Get seat availability for selected movie
    JPanel seatPanel = new JPanel(new GridLayout(2, 5, 10, 10));  // Layout for seat checkboxes
    seatPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30)); // Padding
    seatPanel.setBackground(new Color(80, 80, 80)); // Background color

    // Create checkboxes for seat selection
    JCheckBox[] seatCheckBoxes = new JCheckBox[seats.length];
    for (int i = 0; i < seats.length; i++) {
        seatCheckBoxes[i] = new JCheckBox("Seat " + (i + 1)); // Create checkbox for each seat
        seatCheckBoxes[i].setEnabled(!seats[i]); // Disable checkbox if seat is not available
        seatCheckBoxes[i].setForeground(Color.WHITE); // Checkbox text color
        seatCheckBoxes[i].setBackground(new Color(60, 60, 60)); // Checkbox background color
        seatPanel.add(seatCheckBoxes[i]); // Add checkbox to the panel
    }

    JButton confirmButton = new JButton("Confirm Booking");
    styleButton(confirmButton); // Style the confirm button

    // Action listener for confirm button
    confirmButton.addActionListener(e -> {
        int ticketsBooked = 0; // Counter for booked tickets
        for (int i = 0; i < seatCheckBoxes.length; i++) {
            if (seatCheckBoxes[i].isSelected()) { // Check if the seat is selected
                if (seats[i]) { // Check if the seat is already booked
                    JOptionPane.showMessageDialog(null, "Seat " + (i + 1) + " is already booked."); // Error if seat is already booked
                    return; // Exit the method if a booked seat is selected
                }
                bookings.add(new Booking(username, movie, i + 1)); // Create a new booking
                seats[i] = true; // Mark the seat as booked
                ticketsBooked++; // Increment the booked tickets count
            }
        }

        // Check if tickets booked match the requested tickets
        if (ticketsBooked != numTickets) {
            JOptionPane.showMessageDialog(null, "Please select " + numTickets + " seats."); // Error message
            return; // Exit the method
        }

        // Show success message
        JOptionPane.showMessageDialog(null, "Booking confirmed for " + username + "!\nTickets booked: " + ticketsBooked + " for movie: " + movie);
        showBookingDetails(); // Show booking details
    });

    // Add components to the main window
    getContentPane().removeAll(); // Clear current content
    add(seatPanel, BorderLayout.CENTER); // Add seat panel to the center
    add(confirmButton, BorderLayout.SOUTH); // Add confirm button to the south
    revalidate(); // Refresh the layout
    repaint(); // Repaint the window
}



    // Show booking details
    private void showBookingDetails() {
        getContentPane().removeAll(); // Clear the current content

        bookingDetailsArea = new JTextArea(10, 30); // Text area for displaying bookings
        bookingDetailsArea.setEditable(false); // Make text area non-editable
        bookingDetailsArea.setBackground(new Color(50, 50, 50)); // Background color
        bookingDetailsArea.setForeground(Color.WHITE); // Text color
        bookingDetailsArea.setText(getBookingDetails()); // Load booking details

        // Add the booking details area to the main window
        add(new JScrollPane(bookingDetailsArea), BorderLayout.CENTER); // Scrollable area
        JButton backButton = new JButton("Back to Menu");
        styleButton(backButton); // Style the back button

        // Action listener for back button
        backButton.addActionListener(e -> {
            getContentPane().removeAll(); // Clear current content
            addLoginPanel(); // Show login panel again
            revalidate(); // Refresh the layout
            repaint(); // Repaint the window
        });

        add(backButton, BorderLayout.SOUTH); // Add back button to the bottom
        revalidate(); // Refresh the layout
        repaint(); // Repaint the window
    }

    // Get booking details as a string
    private String getBookingDetails() {
        StringBuilder details = new StringBuilder("Booking Details:\n");
        for (Booking booking : bookings) {
            details.append(booking.toString()).append("\n"); // Append each booking detail
        }
        return details.toString(); // Return all booking details
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Bookings::new); // Create the GUI on the Event Dispatch Thread
    }

    // Inner class to represent a booking
    private static class Booking {
        private final String username; // Username of the booker
        private final String movie; // Movie name
        private final int seat; // Seat number

        public Booking(String username, String movie, int seat) {
            this.username = username; // Set username
            this.movie = movie; // Set movie name
            this.seat = seat; // Set seat number
        }

        @Override
        public String toString() {
            return "User: " + username + ", Movie: " + movie + ", Seat: " + seat; // Return booking information as string
        }
    }

    // Inner class for login action
    private class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText(); // Get username from input
            String password = new String(passwordField.getPassword()); // Get password from input

            // Check if the user is registered
            if (users.containsKey(username) && users.get(username).equals(password)) {
                showBookingForm(username); // Show booking form if login is successful
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password."); // Show error message
            }
        }
    }

    // Inner class for register action
    private class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText(); // Get username from input
            String password = new String(passwordField.getPassword()); // Get password from input

            // Check if the user is already registered
            if (users.containsKey(username)) {
                JOptionPane.showMessageDialog(null, "Username already exists!"); // Show error message
            } else {
                users.put(username, password); // Register the new user
                JOptionPane.showMessageDialog(null, "Registration successful!"); // Show success message
            }
        }
    }
}
