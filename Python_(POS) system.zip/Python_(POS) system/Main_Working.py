class MenuItem:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class System:
    def __init__(self):
        self.menu = {
            'Burger': MenuItem('Burger', 10),
            'Taco': MenuItem('Taco', 15),
            'Chips': MenuItem('Chips', 5),
            'Hotdog': MenuItem('Hotdog', 10),
            'Donuts': MenuItem('Donuts', 5)
        }
        self.order = {}
        self.users = {} 
        
    def register(self, username, password):
        if username in self.users:
            print("Username already exists. Please choose a different username.")
            return True
        else:
            self.users[username] = password
            print("Registration successful!")

         
         
    def login(self, username, password):
        if username in self.users and self.users[username] == password:
            print("Login successful!")
            return True
        else:
            print("Invalid username or password.")
            return False

    def add_to_order(self, item_name, quantity):
        if item_name in self.menu:
            if item_name in self.order:
                self.order[item_name] += quantity
            else:
                self.order[item_name] = quantity
            print(f"{quantity} {item_name}(s) added to the order.")
        else:
            print(f"Sorry, {item_name} is not in the menu.")

    def calculate_bill(self):
        total = 0
        for item_name, quantity in self.order.items():
            total += self.menu[item_name].price * quantity
        return total

    def generate_receipt(self):
        print("\n=== Receipt ===")
        for item_name, quantity in self.order.items():
            print(f"{quantity} {item_name}: R{self.menu[item_name].price * quantity}")
        print(f"Total: R{self.calculate_bill()}")
        print("================\n")

    def menu_management(self):
        print("\n=== Menu ===")
        for item_name, item in self.menu.items():
            print(f"{item_name}: R{item.price}")
        print("============\n")

pos = System()

while True:
    print("1. Register")
    print("2. Login")
    choice = input("Enter the Number of choice: ")
    
    print() 
    
    if choice == '1':
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        pos.register(username, password)
        
        if pos.login(username, password):
            pos.menu_management()
            while True:
                item_name = input("Enter the item you want to order (or 'done' to finish): ").capitalize()
                if item_name == 'Done':
                    break
                quantity = int(input("Enter the quantity: "))
                pos.add_to_order(item_name, quantity)
            pos.generate_receipt()
            break
    elif choice == '3':
        break
    else:
        print("Invalid choice. Please try again.")
    if choice == '2':
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        if pos.login(username, password):
            pos.menu_management()
            while True:
                item_name = input("Enter the item you want to order (or 'done' to finish): ").capitalize()
                if item_name == 'Done':
                    break
                quantity = int(input("Enter the quantity: "))
                pos.add_to_order(item_name, quantity)
            pos.generate_receipt()
            break
    elif choice == '3':
        break
    else:
        print("Invalid choice. Please try again.")