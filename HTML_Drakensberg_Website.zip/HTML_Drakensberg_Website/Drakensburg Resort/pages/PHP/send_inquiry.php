<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    $to = "nadinenaude04@gmail.com";
    $headers = "From: " . $email;
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nSubject: $subject\nMessage:\n$message";

    if (mail($to, "New Inquiry from " . $name, $body, $headers)) {
        echo "Success";
    } else {
        echo "Error";
    }
}
?>
