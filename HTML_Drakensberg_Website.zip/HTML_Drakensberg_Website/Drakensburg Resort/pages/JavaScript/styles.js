// Toggle mobile menu
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');

navToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Close mobile menu when clicking on a link
const navItems = document.querySelectorAll('.nav-links a');
navItems.forEach(item => {
    item.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// Booking form validation (non-functional as per requirements)
const bookingForm = document.querySelector('.booking-form');
if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('This is a demo booking form. In a real application, this would check availability and proceed to booking.');
    });
}

// Testimonial slider (simple version)
let currentTestimonial = 0;
const testimonials = [
    {
        quote: "Our stay at Drakensberg Sun Resort was nothing short of magical. The views are breathtaking, and the staff went above and beyond to make our visit special.",
        name: "Sarah M.",
        rating: 5
    },
    {
        quote: "The perfect mountain getaway. The hiking trails were amazing and the food at the restaurant was exceptional. Highly recommend!",
        name: "John D.",
        rating: 5
    },
    {
        quote: "We loved the spacious rooms and the stunning views. The kids had a great time at the pool while we relaxed at the spa. We'll definitely be back!",
        name: "Maria L.",
        rating: 5
    }
];

function updateTestimonial() {
    const testimonialContainer = document.querySelector('.testimonial');
    if (!testimonialContainer) return;
    
    const current = testimonials[currentTestimonial];
    
    testimonialContainer.innerHTML = `
        <div class="quote">
            <i class="fas fa-quote-left"></i>
            <p>${current.quote}</p>
            <i class="fas fa-quote-right"></i>
        </div>
        <div class="guest-info">
            <h4>${current.name}</h4>
            <div class="rating">
                ${Array(current.rating).fill('<i class="fas fa-star"></i>').join('')}
            </div>
        </div>
    `;
    
    currentTestimonial = (currentTestimonial + 1) % testimonials.length;
}

// Change testimonial every 5 seconds
setInterval(updateTestimonial, 5000);

// Initialize image gallery hover effects
const galleryItems = document.querySelectorAll('.gallery-item');
galleryItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
        const overlay = item.querySelector('.overlay');
        overlay.style.transform = 'translateY(0)';
    });
    
    item.addEventListener('mouseleave', () => {
        const overlay = item.querySelector('.overlay');
        overlay.style.transform = 'translateY(100%)';
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("inquiryForm").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent the default form submission

        let name = document.getElementById("name").value;
        let email = document.getElementById("email").value;
        let phone = document.getElementById("phone").value;
        let subject = document.getElementById("subject").value;
        let message = document.getElementById("message").value;

        if (name && email && subject && message) {
            alert("Thank you for your inquiry, " + name + "! We will get back to you soon.");
            this.reset(); // Reset the form after submission
        } else {
            alert("Please fill in all required fields.");
        }
    });
});
