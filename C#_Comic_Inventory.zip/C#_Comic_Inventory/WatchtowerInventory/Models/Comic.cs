using System;
using System.ComponentModel.DataAnnotations;

namespace WatchtowerInventory.Models
{
    /// <summary>
    /// Represents a comic in the Watchtower inventory.
    /// </summary>
    public class Comic
    {
        /// <summary>
        /// Unique identifier for the comic.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Title of the comic.
        /// </summary>
        [Required]
        [StringLength(150)]
        public string? Title { get; set; }

        /// <summary>
        /// Author of the comic.
        /// </summary>
        [Required]
        [StringLength(100)]
        public string? Author { get; set; }

        /// <summary>
        /// Genre or category (e.g., manga, superhero, indie).
        /// </summary>
        [Required]
        public string? Genre { get; set; }

        /// <summary>
        /// Publisher of the comic.
        /// </summary>
        public string? Publisher { get; set; }

        /// <summary>
        /// Date the comic was published.
        /// </summary>
        public DateTime PublicationDate { get; set; }

        /// <summary>
        /// Price of the comic.
        /// </summary>
        [Range(0.0, 999.99)]
        public decimal Price { get; set; }

        /// <summary>
        /// Quantity of this comic in stock.
        /// </summary>
        [Range(0, int.MaxValue)]
        public int Stock { get; set; }

        /// <summary>
        /// Short description or summary of the comic's story.
        /// </summary>
        [StringLength(1000)]
        public string? Synopsis { get; set; }

        /// <summary>
        /// URL to the comic's cover image.
        /// </summary>
        [Url]
        public string? ImageUrl { get; set; }

        
    }
}
