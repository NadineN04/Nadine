using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WatchtowerInventory.Models;


public class AdminController : Controller
{
    // Simulated in-memory "database"
    private static List<Comic> Comics = new List<Comic>
    {
        new Comic { Id = 1, Title = "Spider-Man", Author = "Stan Lee", Genre = "Superhero", Price = 9.99M, Stock = 10 },
        new Comic { Id = 2, Title = "Batman", Author = "Bob Kane", Genre = "Superhero", Price = 8.99M, Stock = 5 }
    };

    public IActionResult Admin()
{
    var comics = ComicRepository.GetAll(); // This ensures Admin shows all comics
    return View(comics);
}



    [HttpPost]
public IActionResult Edit(Comic updatedComic)
{
    ComicRepository.Update(updatedComic);
    return RedirectToAction("Admin");
}


    [HttpPost]
public IActionResult Delete(int id)
{
    ComicRepository.Delete(id);
    return RedirectToAction("Admin");
}

[HttpPost]
public IActionResult Add(Comic comic)
{
    ComicRepository.AddComic(comic);

    // Redirect to HomeController's Index action
    return RedirectToAction("Index", "Home");
}


public IActionResult Index()
{
    var comics = ComicRepository.GetAll();
    // Use the same in-memory list from AdminController or refactor into a shared service
    return View(AdminController.Comics); // or wherever the comic list lives
}


}
