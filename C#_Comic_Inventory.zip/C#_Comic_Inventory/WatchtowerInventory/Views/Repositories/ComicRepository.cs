using System.Collections.Generic;
using System.Linq;

namespace WatchtowerInventory.Models
{
    public static class ComicRepository
    {
        // Shared in-memory comic list
        private static List<Comic> comics = new List<Comic>();

        public static List<Comic> GetAll()
        {
            return comics;
        }

        public static void AddComic(Comic comic)
        {
            comic.Id = comics.Count > 0 ? comics.Max(c => c.Id) + 1 : 1;
            comics.Add(comic);
        }

        public static void Update(Comic updatedComic)
        {
            var comic = comics.FirstOrDefault(c => c.Id == updatedComic.Id);
            if (comic != null)
            {
                comic.Title = updatedComic.Title;
                comic.Publisher = updatedComic.Publisher;
                comic.Price = updatedComic.Price;
                comic.Stock = updatedComic.Stock;
                comic.ImageUrl = updatedComic.ImageUrl;
            }
        }

        public static void Delete(int id)
        {
            var comic = comics.FirstOrDefault(c => c.Id == id);
            if (comic != null)
            {
                comics.Remove(comic);
            }
        }
    }
}
